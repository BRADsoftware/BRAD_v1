function varargout = BRAD_v01_WB(varargin)
% BRAD_V01_WB MATLAB code for BRAD_v01_WB.fig
%      BRAD_V01_WB, by itself, creates a new BRAD_V01_WB or raises the existing
%      singleton*.
%
%      H = BRAD_V01_WB returns the handle to a new BRAD_V01_WB or the handle to
%      the existing singleton*.
%
%      BRAD_V01_WB('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in BRAD_V01_WB.M with the given input arguments.
%
%      BRAD_V01_WB('Property','Value',...) creates a new BRAD_V01_WB or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before BRAD_v01_WB_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to BRAD_v01_WB_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help BRAD_v01_WB

% Last Modified by GUIDE v2.5 30-Aug-2017 16:27:15

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @BRAD_v01_WB_OpeningFcn, ...
                   'gui_OutputFcn',  @BRAD_v01_WB_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before BRAD_v01_WB is made visible.
function BRAD_v01_WB_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to BRAD_v01_WB (see VARARGIN)

% Choose default command line output for BRAD_v01_WB
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes BRAD_v01_WB wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = BRAD_v01_WB_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on button press in pushbuttonCalc.
function pushbuttonCalc_Callback(hObject, eventdata, handles)
% hObject    handle to pushbuttonCalc (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
calculateForBrainLevel(hObject, eventdata, handles);
saveWholeBrainLevel(hObject, eventdata, handles);

% --- Executes on selection change in popupmenuDecMethod.
function popupmenuDecMethod_Callback(hObject, eventdata, handles)
% hObject    handle to popupmenuDecMethod (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns popupmenuDecMethod contents as cell array
%        contents{get(hObject,'Value')} returns selected item from popupmenuDecMethod
global method;
str = get(handles.popupmenuDecMethod,'String');
val = get(handles.popupmenuDecMethod,'Value');
method = str{val};


% --- Executes during object creation, after setting all properties.
function popupmenuDecMethod_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popupmenuDecMethod (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in popupmenuSC.
function popupmenuSC_Callback(hObject, eventdata, handles)
% hObject    handle to popupmenuSC (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns popupmenuSC contents as cell array
%        contents{get(hObject,'Value')} returns selected item from popupmenuSC

global SC;
str = get(handles.popupmenuSC,'String');
val = get(handles.popupmenuSC,'Value');
SC = str{val};


% --- Executes during object creation, after setting all properties.
function popupmenuSC_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popupmenuSC (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in pushbuttonImpData.
function pushbuttonImpData_Callback(hObject, eventdata, handles)
% hObject    handle to pushbuttonImpData (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

global import;
global parameter;
global wholeBrain;

loadFolders(hObject, eventdata, handles);

[filename pathname] = uigetfile({'*.nii'}, 'Select file (BOLD-signal)');
addpath(pathname);
import.fpath.wholeBrain = strcat(pathname, filename);
import.file.wholeBrain = filename;
set(handles.textImport, 'String', import.file.wholeBrain);

loadWholeBrainData(hObject, eventdata, handles);
loadingParameters(hObject, eventdata, handles);
parameter.maxIteration = 4*max(size(wholeBrain));



function loadingParameters(hObject, eventdata, handles)

global parameter;

parameter = usualParameters;





% --- Executes on button press in pushbuttonImpMask.
function pushbuttonImpMask_Callback(hObject, eventdata, handles)
% hObject    handle to pushbuttonImpMask (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


global import;

loadFolders(hObject, eventdata, handles);

[filename pathname] = uigetfile({'*.nii'}, 'Select gray-matter mask:');
addpath(pathname);
import.fpath.mask = strcat(pathname, filename);
import.file.mask = filename;
set(handles.textMask, 'String', import.file.mask);

loadMask(hObject, eventdata, handles);




% --- Executes on button press in pushbuttonImprHRF.
function pushbuttonImprHRF_Callback(hObject, eventdata, handles)
% hObject    handle to pushbuttonImprHRF (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

global import;
global parameter;
global hrf;


if get(handles.checkboxDefKern,'Value') == get(handles.checkboxDefKern,'Max')
    hrf = spm_hrf(str2double(handles.editRT.String));
    set(handles.textHRF, 'String', ['Generated SPM HRF, RT: ' handles.editRT.String]);
else
    [filename pathname] = uigetfile({'*.csv'}, 'Select file (HRF)');
    addpath(pathname);
    import.fpath.HRf = strcat(pathname, filename);
    import.file.HRf = filename;

    hrf = parameter.constForHRF*load(import.file.HRf);
    set(handles.textHRF, 'String', import.file.HRf);
end;




function loadFolders(hObject, eventdata, handles)
%{
    Initialization.
%}

addpath('Functions');
addpath('Functions/Deconvolution');
addpath('Functions/Technical');
addpath('Functions/PD_pursuit');
addpath('Functions/Filtering');

addpath('Input');
addpath('Input/HRF');
addpath('Input/Time series');
addpath('Input/Spectrum');



function loadWholeBrainData(hObject, eventdata, handles)
%{
    Load data: .mat-file with 4D array (3D+time) with name 'wholeBrain'
%}

global import;
global wholeBrain;
global wB_head;

h = waitbar(0,'Loading the data. Please wait...');
%{
% get the name of variable inside the .mat file
tt = whos('-file',import.fpath.wholeBrain);
% read this variable (4-D matrix)
varTMP = load(import.fpath.wholeBrain,tt.name); % from here we get 'wholeBrain'
% save 4-D matrix into 'wholeBrain' variable
wholeBrain = varTMP.(tt.name);
%}
wB_head=spm_vol(import.fpath.wholeBrain); 
wholeBrain=spm_read_vols(wB_head); % vol_mat=data from .nii converted to double
close(h);

function loadMask(hObject, eventdata, handles)
%{
    Load data: .mat-file with 3D array with name 'mask' which contains
    gray-matter mask
%}

global import;
global mask;
global mask_head;

h = waitbar(0,'Loading the gray-matter mask. Please wait...');
%{
% get the name of variable inside the .mat file (mask)
tt = whos('-file',import.fpath.mask);
% read this variable (4-D matrix) (mask)
varTMP = load(import.fpath.mask,tt.name); % from here we get 'mask'
mask = varTMP.(tt.name);
%}

mask_head=spm_vol(import.fpath.mask); 
mask=spm_read_vols(mask_head);

close(h);


function saveWholeBrainLevel(hObject, eventdata, handles)
%{
    Save whole brain level deconvolution results
%}

global estimateWB;
global wB_head;

[file,path] = uiputfile(['WholeBrain_' date() '.nii'],'Save file name');

for i=1:size(wB_head,1)
    wB_head(i).fname=fullfile(path,file);
    spm_write_vol(wB_head(i),estimateWB(:,:,:,i));    
end;



function calculateForBrainLevel(hObject, eventdata, handles)
%{
    Calculation of the deconvolution on a whole brain level using DS
%}

global wholeBrain;
global mask;
global parameterF;
global hrf;
global parameter;
global estimateWB;
global SC;
global method;

parameterF = parameter;
parameterF.hrf = hrf;

popupmenuDecMethod_Callback(hObject, eventdata, handles);
popupmenuSC_Callback(hObject, eventdata, handles);

maskFlat = zeros(size(mask));
maskFlat(find(mask>0.99998)) = 1;

sizeVox = size(wholeBrain);
lenS = sizeVox(4);

h = waitbar(0,'Calculation for whole brain level. Please, wait...');
num = 0;
estimateWB = zeros(size(wholeBrain));
for i1 = 1:sizeVox(1)
    for i2 = 1:sizeVox(2)
        for i3 = 1:sizeVox(3)
            if maskFlat(i1,i2,i3) 
                sgn = nrmlz01(reshape(wholeBrain(i1,i2,i3,:),lenS,1));
                if sum(abs(sgn))==0
                    eWB = zeros(size(sgn));
                else
                    eWB = calculateEstimate(sgn,method,SC,parameterF);
                end;
                
                estimateWB(i1,i2,i3,:) = eWB;
                num = num+1;
            end;
        end;
    end;
    perc = round(num/sum(sum(sum(maskFlat))),3);
    disp(perc);
    h = waitbar(perc);
end;
close(h);



function eWB = calculateEstimate(y,method,SC,parameterF)
%{
    Make calculations for signal y.
%}

global parameter;
global hrf;

parameterF = parameter;
parameterF.hrf = hrf;
H = ToeplitzMatrix(hrf,length(y));


% possible estimates
switch method
case 'DS'
    [estSet, lambdaset.DS] = decDSset(y, parameterF);
    
    bestIndexA = parameterSelection(y,estSet,H,0);
    bestIndexB = parameterSelection(y,estSet,H,1);
    
    finalEstimate.DS.MIC = selectEstimate(estSet,'MT',lambdaset.DS);
    finalEstimate.DS.AIC = selectEstimate(estSet,'AIC',bestIndexA);
    finalEstimate.DS.BIC = selectEstimate(estSet,'BIC',bestIndexB);
    finalEstimate.DS.AllPeaks = selectEstimate(estSet,'AllP',length(y));

case 'LASSO'
    [estSet, lambdaset.LASSO] = decLASSOset(y, parameterF);
        
    bestIndexA = parameterSelection(y,estSet,H,0);
    bestIndexB = parameterSelection(y,estSet,H,1);
    
    finalEstimate.LASSO.MIC = selectEstimate(estSet,'MT',lambdaset.LASSO);
    finalEstimate.LASSO.AIC = selectEstimate(estSet,'AIC',bestIndexA);
    finalEstimate.LASSO.BIC = selectEstimate(estSet,'BIC',bestIndexB);
    finalEstimate.LASSO.AllPeaks = selectEstimate(estSet,'AllP',length(y));
end;
eWB = finalEstimate.(method).(SC);


% --- Executes on button press in checkboxDefKern.
function checkboxDefKern_Callback(hObject, eventdata, handles)
% hObject    handle to checkboxDefKern (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of checkboxDefKern



function editRT_Callback(hObject, eventdata, handles)
% hObject    handle to editRT (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of editRT as text
%        str2double(get(hObject,'String')) returns contents of editRT as a double


% --- Executes during object creation, after setting all properties.
function editRT_CreateFcn(hObject, eventdata, handles)
% hObject    handle to editRT (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
