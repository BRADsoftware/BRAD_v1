function [H] = ToeplitzMatrix(hrf, lenS)
% Building of Toeplitz matrix (dimention lenS*lenS) using the column hrf
% (less then lenS)
rowH = [hrf(1), zeros(1,lenS-1)];
colH = [hrf; zeros(lenS-length(hrf),1)];
H = toeplitz(colH, rowH);
end