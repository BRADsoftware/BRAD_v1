function [h] = estH(x,s,N,xi,a)
% kernel smoothing of the density
% xi - vector of values, x - current number, s - width of kernel, 
% N - length of vector (N = length(xi)), a - vector of weights
listK = arrayfun(@(i) K2((x-xi(i))/s),1:N);
h = 1/s*1/N*sum(a.*listK');
end