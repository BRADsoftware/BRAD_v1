function hNew = nrmlz01(h)
% Rescale of vector h to [0,1] segment

hNew = (h-min(h))/(max(h)-min(h));

end