function [currentEstimate] = knownPeaksAmount(estimatesSet,M)
%{
    Selection of the estimate number M from matrix estimatesSet

Input:
     - estimatesSet - NxK matrix containing K estimates of length N
     - M - number from 1 to K, corresponds to needed number of peaks in the estimate

Output:
    - currentEstimate - chosen estimate from estimateSet matrix

%}

peaksAmount = sum((estimatesSet~=0),1);

% s - vector, r - value, which I'd like to find in s
closestPoint = @(s,r) find(abs(s-r) == min(abs(s-r)));

nM = min(closestPoint(peaksAmount,M));

currentEstimate = estimatesSet(:,nM);

end