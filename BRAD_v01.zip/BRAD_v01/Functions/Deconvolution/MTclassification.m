function [est0,ind] = MTclassification(est,lambda)
%{
    Using Mixture Theory  for classification peaks (activations vs noise)

Input:
    - est - NxK matrix, set of estimates for set of parameters. K
    estimates, each estimate of length N
    - lambda - 1xK vector of parameters (lambda for lasso of
    PD_pursuit)

Output:
    - ind - indexes of activations (not noise)
    - est0 - Nx1 vector, "cleaned" estimate

Comment: 
    sd = 1; width of kernel in mixture theory
%}

lenS = size(est,1);
maxK = size(est,2);

if sum(abs(est(1,:))>sum(abs(est(lenS,:))))
    estT = est(:,1:end-1);
else
    estT = est(:,2:end);
end;

if maxK == 1
    ind = lambda(1);
    omega = 1;
else
    listDeltaT = lambda(1:maxK-1) - lambda(2:maxK);
    
    omega = zeros(lenS,1);
    for p = 1:lenS
        omega(p) = sum((estT(p,:)~=0).*listDeltaT)./max(lambda);
    end;

    detGammaN = mean(omega.^2)-mean(omega)^2;
    s2 = mean(omega.^2);
    s1 = mean(omega);
    a1 = ((1-s1)*omega+(s2-s1))/detGammaN;
    a2 = (s2-s1*omega)/detGammaN;

    H1 = zeros(1,lenS);
    H2 = zeros(1,lenS);
    for p=2:lenS
        dopH1 = a1(1:p-1);
        dopH2 = a2(1:p-1);
        H1(p) = 1/lenS*sum(dopH1);
        H2(p) = 1/lenS*sum(dopH2);
    end;

    sd = 1;
    listH1=zeros(1,lenS);
    listH2=zeros(1,lenS);
    for p=1:lenS
        listH1(p)=estH(p,sd,lenS,1:lenS,a1);
        listH2(p)=estH(p,sd,lenS,1:lenS,a2);
    end;

    ind=find(omega.*listH1'>(1-omega).*listH2');
end;
    
est0 = zeros(lenS,1);
est0(ind) = 1;
est0 = est0.*mean(est,2);

end
