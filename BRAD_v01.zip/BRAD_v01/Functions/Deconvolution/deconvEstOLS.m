function [estimateOLS] = deconvEstOLS(output, parameter)
% Find the OLS-estimate for the signals output

% Toeplitz matrix
sizeOutput = size(output);
H1 = ToeplitzMatrix(parameter.hrf,sizeOutput(1));

% OLS-estimate
estOLS = @(y) (H1'*H1)\(H1'*y); %(inv(H'*H)*H')*y

estimateOLS = cell2mat(arrayfun(@(k) estOLS(output(:,k)), 1:sizeOutput(2),'UniformOutput',false));

end