function [estimateDSC] = deconvEstDSC(output, parameter)
% Find the Dantzig Selector estimate for the signals output

% Toeplitz matrix
sizeOutput = size(output);
H1 = ToeplitzMatrix(parameter.hrf,sizeOutput(1));

% OLS-estimate
estOLS = @(y) (H1'*H1)\(H1'*y); %(inv(H'*H)*H')*y

for k = 1:sizeOutput(2)
    y = output(:,k);
    estimateOLS = estOLS(y);
    
    % Find the indexes of non-zero peaks
    [ind] = DS_classification(y, H1, 'N',parameter.accurancy, parameter.maxIteration, parameter.sd);
    
    % Choose only non-zero peaks from the OLS estimate.
    estimateDSC(:,k) = zeros(sizeOutput(1),1);
    estimateDSC(ind,k) = estimateOLS(ind);
end

end