function [estLASSOset, lambdaset] = decLASSOset(output, parameter)
% Find the LASSO-estimate for the signals output (output 1D-vector!!)
% For choosing of one particular signal we're using the minimum of
% residuals

% Toeplitz matrix
sizeOutput = size(output);
H1 = ToeplitzMatrix(parameter.hrf,sizeOutput(1));

y = output;
[estLASSOset,fitInfo] = lasso(H1,y);

lambdaset = fitInfo.Lambda;

end