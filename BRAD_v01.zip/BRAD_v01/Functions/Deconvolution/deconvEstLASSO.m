function [estimateLASSO] = deconvEstLASSO(output, parameter)
% Find the LASSO-estimate for the signals output
% For choosing of one particular signal we're using the minimum of
% residuals

% Toeplitz matrix
sizeOutput = size(output);
H1 = ToeplitzMatrix(parameter.hrf,sizeOutput(1));

for k = 1:sizeOutput(2)
    y = output(:,k);
        
    [est,fit] = lasso(H1,y);
    
    [l1,l2] = size(est);
    sgn = zeros(size(est));
    for i = 1:l2
        sgn(:,i) = (H1*est(:,i));
    end;

    index = parameterSelection(y,est,H1);
    
    estimateLASSO(:,k) = est(:,index);
end

end