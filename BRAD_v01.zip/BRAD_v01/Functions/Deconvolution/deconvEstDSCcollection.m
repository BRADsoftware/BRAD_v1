function [estimateDSCcoll] = deconvEstDSCcollection(output, parameter)
% (Collection of estimates)
% Find the Dantzig Selector estimate for the signal 'output'
% 'output' = 1D-vector! 

% Toeplitz matrix
sizeOutput = size(output);
H1 = ToeplitzMatrix(parameter.hrf,sizeOutput(1));

% OLS-estimate
estOLS = @(y) (H1'*H1)\(H1'*y); %(inv(H'*H)*H')*y

y = output;
estimateOLS = estOLS(y);
        
[ind, omega] = DS_classification(y, H1, 'N',parameter.accurancy, parameter.maxIteration, parameter.sd);
    
sortedPr=sort(omega,'descend');

for k=1:length(omega)
    treshP=sortedPr(k);
    estimateDSCcoll(:,k) = estimateOLS.*logical(omega>treshP)';
end

end