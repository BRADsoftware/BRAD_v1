function [estimateOLScoll] = decOLSset(output, parameter)
% Find the OLS-estimate for the signals output
% output - 1D vector!

% Toeplitz matrix
sizeOutput = size(output);
H1 = ToeplitzMatrix(parameter.hrf,sizeOutput(1));

% OLS-estimate
estOLS = @(y) (H1'*H1)\(H1'*y); %(inv(H'*H)*H')*y

y = output;
estimateOLS = estOLS(y);
sorted=sort(abs(estimateOLS),'descend');
    
for k = 1:length(y)    
    tresh=sorted(k);
    estimateOLScoll(:,k) = estimateOLS.*logical(abs(estimateOLS)>tresh);
end

end