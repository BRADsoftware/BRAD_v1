function [bestindex] = parameterSelection(y,estimates,H,criteria)
%{
 Selection Criteria: BIC or AIC
BIC: 
    optimalIndex = arg min [ N*log(||y-H*s(index)||_2^2) + log(N)*df(index)]
AIC: 
    optimalIndex = arg min [ N*log(||y-H*s(index)||_2^2) + 2*df(index)]
Here df is degrees of freedoms, its estimate is: df(index) = #{j: s(index,j) ~= 0}
 (number of nonzero elements in the solution, corresponding to particula index)


Input:
y - Nx1 vector-column, original signal to be deconvolved
estimates - NxK matrix, containing K estimates of deconvolved y
H - convolution (Toeplitz) matrix, NxN
criteria - numerical value, 0 for AIC, everything else for BIC
%}

if nargin<4
    criteria = 1;
end;

N = length(y);
maxK = size(estimates,2);

% AIC or BIC
if criteria
    wn = log(N);
else 
    wn = 2;
end;

yEst = zeros(size(estimates));
df = zeros(1,maxK);
res = zeros(1,maxK);
for k=1:maxK
    yEst(:,k) = H*estimates(:,k);
    df(k) = nnz(estimates(:,k));
    res(k) = log(norm(y - yEst(:,k))^2);
end;

crit = N*res + wn*df;
bestindex = find(crit==min(crit));

end