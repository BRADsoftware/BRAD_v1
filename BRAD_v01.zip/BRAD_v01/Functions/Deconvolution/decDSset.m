function [estDSset, lambdaset] = decDSset(output, parameter)
% (Collection of estimates)
% Find the Dantzig Selector estimate for the signal 'output'
% 'output' = 1D-vector! 

% Toeplitz matrix
sizeOutput = size(output);
H1 = ToeplitzMatrix(parameter.hrf,sizeOutput(1));
       
[lambdaset, listGammaX, estDSset] = PD_pursuit_function_listSupp(H1, H1'*H1, output, parameter.accurancy, parameter.maxIteration);
    
end