function [parameter] = usualParameters()

parameter.type = 'ind'; % type = 'ind' or type = 'len'; corresponds to the xi(j) = j or xi(j) = length(s_j)
parameter.accurancy = 10^(-12);
parameter.maxIteration = 1000;
parameter.sd = 1;
parameter.constForHRF = 5;

end
