function [res, res2] = nullDistFacesDetection(mask,est01,nSim, mark, D)

if nargin<5
    D = 'N';
end;

% dFp = detected faces percent, x - mask (0...1), y - test
dFp = @(x,y) sum(x(find(y==1)));

% ndFp = not detected faces percent, x - mask (0...1), y - test
ndFp = @(x,y) sum(x(find(y==0)));

res = struct();
nAct = sum(est01);
res = struct();
for i = 1:nSim
    ind = randperm(length(est01),nAct);
    estT = zeros(size(est01));
    estT(ind) = 1;
    res(i).df = dFp(mask,estT);
    res(i).ndf = ndFp(mask,estT);
end;

display([mark ' dFp: ' mat2str(length(find([res.df]<dFp(mask,est01)))/nSim)]);
display([mark ' ndFp: ' mat2str(length(find([res.ndf]<ndFp(mask,est01)))/nSim)]);

if strcmp(D,'Y')
    figure;
    subplot(2,1,1); hist([res.df]); title([mark ' dFp ' mat2str(dFp(mask,est01))]);
    subplot(2,1,2); hist([res.ndf]); title([mark ' ndFp ' mat2str(ndFp(mask,est01))]);
end;

est16 = zeros(size(est01));
activations = [3 5 6 22 56 76 77 82 130 152 193 194 197 198 232 233];
est16(activations) = 1;

nAct = sum(est16);
res2 = struct();
for i = 1:nSim
    ind = randperm(length(est01),nAct);
    estT = zeros(size(est01));
    estT(ind) = 1;
    res2(i).df = dFp(mask,estT);
    res2(i).ndf = ndFp(mask,estT);
end;

display(['16 peaks, ' mark ' dFp: ' mat2str(length(find([res2.df]<dFp(mask,est16)))/nSim)]);
display(['16 peaks, ' mark ' ndFp: ' mat2str(length(find([res2.ndf]<ndFp(mask,est16)))/nSim)]);

if strcmp(D,'Y')
    figure;
    subplot(2,1,1); hist([res2.df]); title([mark ' dFp ' mat2str(dFp(mask,est16))]);
    subplot(2,1,2); hist([res2.ndf]); title([mark ' ndFp ' mat2str(ndFp(mask,est16))]);
end;

end