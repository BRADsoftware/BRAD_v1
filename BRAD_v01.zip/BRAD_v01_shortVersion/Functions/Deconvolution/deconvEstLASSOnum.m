function [estimateLASSO] = deconvEstLASSOnum(output, parameter, decParameter)
% Find the LASSO-estimate for the signals output

% Toeplitz matrix
sizeOutput = size(output);
H1 = ToeplitzMatrix(parameter.hrf,sizeOutput(1));

num = decParameter.num;

for k = 1:sizeOutput(2)
    y = output(:,k);
        
    [est,fit] = lasso(H1,y);
    
    fitDF = fit.DF;
    
    diff = abs(fitDF - num);
    index = find(diff == min(diff));
    if length(index)>1
        index = index(1);
    end;
    
    estimateLASSO(:,k) = est(:,index);
end

end