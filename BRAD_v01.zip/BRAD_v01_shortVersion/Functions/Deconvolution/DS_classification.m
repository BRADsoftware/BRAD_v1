function [ind, omega] = DS_classification(y, H, demonstration, accurancy, maxIteration, sd)
% Classification usion DS (PD-pursuit) and mixed probabilities

% Dantzig selector: PD_pursuit
[listT, listGammaX] = PD_pursuit_function_listSupp(H, H'*H, y, accurancy, maxIteration);
maxK = length(listT);
lenS = length(y);

if maxK == 1
    ind = listGammaX{1};
    omega = [1];
%    break
else
peaksApp = zeros(maxK-1,lenS); % Array of appearence of peaks during the algorithm
for k = 1:maxK-1 
    peaksApp(k,listGammaX{k}) = 1;
end
listDeltaT = listT(1:maxK-1) - listT(2:maxK);

peaksProbFull=zeros(1,lenS);
%peaksProbMax=zeros(1,lenS);
for p = 1:lenS
    peaksProbFull(p) = sum(peaksApp(:,p).*listDeltaT')/listT(1);
end

omega = peaksProbFull;
detGammaN = mean(omega.^2)-mean(omega)^2;
s2 = mean(omega.^2);
s1 = mean(omega);
a1 = ((1-s1)*omega+(s2-s1))/detGammaN;
a2 = (s2-s1*omega)/detGammaN;

H1 = zeros(1,lenS);
H2 = zeros(1,lenS);
for p=2:lenS
    dopH1 = a1(1:p-1);
    dopH2 = a2(1:p-1);
    H1(p) = 1/lenS*sum(dopH1);
    H2(p) = 1/lenS*sum(dopH2);
end

%sd=4;
listH1=zeros(1,p);
listH2=zeros(1,p);
for p=1:lenS
    listH1(p)=estH(p,sd,lenS,1:lenS,a1);
    listH2(p)=estH(p,sd,lenS,1:lenS,a2);
end

ind=find(omega.*listH1>(1-omega).*listH2);
%estimatedPeaks = zeros(1,p);
%estimatedPeaks(ind)=1;


if demonstration=='Y'
    figure;
    plot(1:lenS,H1,1:lenS,H2);
    title('Estimates of distribution functions of components');

    figure;
    plot(1:lenS,omega.*listH1,1:lenS,(1-omega).*listH2);
    title('Classification: red one is noise');

 %   figure;
 %   plot(estimatedPeaks);
 %   title('Estimated peaks');

 %   figure;
 %   plot(1:lenS,y,1:lenS,max(y)*estimatedPeaks);
 %   title('Places of estimated peaks');
end
end
end