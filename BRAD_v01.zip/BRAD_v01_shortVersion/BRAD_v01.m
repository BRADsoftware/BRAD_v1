function varargout = BRAD_v01(varargin)
%{
    Created by Anna Pidnebesna.
    E-mail: BrainActivityDetection@gmail.com
%}


% BRAD_V01 MATLAB code for BRAD_v01.fig
%      BRAD_V01, by itself, creates a new BRAD_V01 or raises the existing
%      singleton*.
%
%      H = BRAD_V01 returns the handle to a new BRAD_V01 or the handle to
%      the existing singleton*.
%
%      BRAD_V01('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in BRAD_V01.M with the given input arguments.
%
%      BRAD_V01('Property','Value',...) creates a new BRAD_V01 or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before BRAD_v01_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to BRAD_v01_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%

% Last Modified by GUIDE v2.5 26-Jan-2017 16:54:49


% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @BRAD_v01_OpeningFcn, ...
                   'gui_OutputFcn',  @BRAD_v01_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before BRAD_v01 is made visible.
function BRAD_v01_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to BRAD_v01 (see VARARGIN)

% Choose default command line output for BRAD_v01
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes BRAD_v01 wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = BRAD_v01_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;





%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%% LOAD SETTINGS AND DATA %%%%%%%%%%%%%%%%%%%%%%%%%




% --- Executes on button press in pushbuttonLoadImportSettings.
function pushbuttonLoadImportSettings_Callback(hObject, eventdata, handles)
% hObject    handle to pushbuttonLoadImportSettings (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

%{
    The dialog for opening the import settings file after pressing the
    button "Import settings"
%}

[filename pathname] = uigetfile({'*.mat'}, 'Select file');
loadImprotSettings(filename, pathname, hObject, eventdata, handles);



function loadImprotSettings(filename, pathname, hObject, eventdata, handles)
%{
    Import file with the input settings
%}
global import;
global parameter;
global settings;

loadFolders(hObject, eventdata, handles);
parameter = usualParameters;

load([pathname filename]);

setLoadedSettings(hObject, eventdata, handles);

loadSignal(hObject, eventdata, handles);
loadKernel(hObject, eventdata, handles);
loadSpectr(hObject, eventdata, handles);

updateSignalType(hObject, eventdata, handles);


% --- Executes on button press in pushbuttonLoadCalc.
function pushbuttonLoadCalc_Callback(hObject, eventdata, handles)
% hObject    handle to pushbuttonLoadCalc (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

%{
    Dialog for loading previous calculation.
%}

global estimate;
global settings;
global yO;
global yF;
global y;
global import;


%{
    Choose the file to load. Load data.
%}

[filename pathname] = uigetfile({'*.mat'}, 'Select file');
load([pathname filename]);


%{
    Set settings corresponding to the loaded data.
%}
setLoadedSettings(hObject, eventdata, handles);
deconvolutionButtonsAvailability(hObject, eventdata, handles);

%{
    Display the loaded BOLD-signal on the chart.
%}
updateSignalType(hObject, eventdata, handles);
plot(y);
set(handles.text1, 'String', import.file.signal);
set(handles.textHRf, 'String', import.file.HRf);





function deconvolutionButtonsAvailability(hObject, eventdata, handles)
%{
    Enabling the deconvolution buttons.
%}

global settings;

if settings.calculations.DSC==1
    set(handles.pushbuttonDSC, 'Enable', 'On');
else
    set(handles.pushbuttonDSC, 'Enable', 'Off');
end;

if settings.calculations.OLS==1
    set(handles.pushbuttonOLS, 'Enable', 'On');
else
    set(handles.pushbuttonOLS, 'Enable', 'Off');
end;
if settings.calculations.LASSO==1
    set(handles.pushbuttonLASSO, 'Enable', 'On');
else 
    set(handles.pushbuttonLASSO, 'Enable', 'Off');
end;


function setLoadedSettings(hObject, eventdata, handles)
%{
  Set loaded settings.
%}
global settings;

set(handles.checkboxCalcDSC,'Value', settings.calculations.DSC);
set(handles.checkboxCalcOLS,'Value', settings.calculations.OLS);
set(handles.checkboxCalcLASSO,'Value', settings.calculations.LASSO);
set(handles.checkboxCalcOrS,'Value',settings.calculations.OriginalSignal);
set(handles.checkboxCalcFiltering,'Value', settings.calculations.Filtering);
set(handles.checkboxCalcFr,'Value', settings.calculations.Fr);

set(handles.editSpeed1,'Value', settings.calculations.TR1);
set(handles.editSpeed2,'Value', settings.calculations.TR2);

set(handles.radiobuttonOrSignal,'Value', settings.originalSignal);
set(handles.radiobuttonFilSignal,'Value', settings.filteredSignal);

set(handles.radiobuttonSpDef,'Value', settings.spectrumDef);
set(handles.radiobuttonSpFit,'Value', settings.spectrumFit);
set(handles.radiobuttonSpLoad,'Value', settings.spectrumLoad);

%set(handles.checkboxMovieBlock,'Value', settings.movieuse);


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%% SAVE SETTINGS AND DATA %%%%%%%%%%%%%%%%%%%%%%%%%


% --- Executes on button press in pushbuttonSaveDecS.
function pushbuttonSaveDecS_Callback(hObject, eventdata, handles)
% hObject    handle to pushbuttonSaveDecS (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

%{
    Save the current estimate.
%}

global import;
global currentEstimate;

uisave({'currentEstimate'}, ['DeconvolvedSignal_' strrep(import.file.signal,'.dat','') '_' date '.mat']);


% --- Executes on button press in pushbuttonSaveInputSettings.
function pushbuttonSaveInputSettings_Callback(hObject, eventdata, handles)
% hObject    handle to pushbuttonSaveInputSettings (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

%{
    Save the current input settings.
%}
global import;
global settings;

uisave({'import','settings'}, ['ImportSettings_' strrep(import.file.signal,'.dat','') '_' date '.mat']);


% --- Executes on button press in pushbuttonSaveAllSettings.
function pushbuttonSaveCalculations_Callback(hObject, eventdata, handles)
% hObject    handle to pushbuttonSaveAllSettings (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

%{
    Save calculation results, all estimates, input settings, calculation and visualization settings, and frames.
%}

global import;
global settings;
global estimate;
global yO;
global yF;
global def;
global collection;
global peaksAmount;
global frames;
global signalType;

uisave({'settings','estimate','yO','yF','def','collection','peaksAmount','frames','signalType','import'}, ['AllCalculations_' strrep(import.file.signal,'.dat','') '_' date '.mat']);


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%% IMPORT DATA AND STARTING SETTINGS %%%%%%%%%%%%%%%%%%%%%


function loadFolders(hObject, eventdata, handles)
%{
    Initialization.
%}

addpath('Functions');
addpath('Functions/Deconvolution');
addpath('Functions/Temporal');
addpath('Functions/Technical');
addpath('Functions/PD_pursuit');
addpath('Functions/OLD');
addpath('Functions/Filtering');

addpath('Input');
addpath('Input/Frames');
addpath('Input/HRF');
addpath('Input/Movies');
addpath('Input/Time series');
addpath('Input/Spectrum');




% --- Executes on button press in pushbuttonImpSignal.
function pushbuttonImpSignal_Callback(hObject, eventdata, handles)
% hObject    handle to pushbuttonImpSignal (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


%{
    Import BOLD-signal.
%}

global import;
global parameter;

[filename pathname] = uigetfile({'*.dat'}, 'Select file (BOLD-signal)');
import.fpath.signal = strcat(pathname, filename);
import.file.signal = filename;

loadFolders;
loadSignal(hObject, eventdata, handles);
loadingParameters(hObject, eventdata, handles);

startingSettings(hObject, eventdata, handles);


function startingSettings(hObject, eventdata, handles)
%{
    Starting settings: Disabling results buttons before calculations; clearing the resulted
    signals;
%}

global yF;
global peaksAmount;

yF = 0;
peaksAmount = {};

set(handles.pushbuttonDSC, 'Enable', 'Off');
set(handles.pushbuttonOLS, 'Enable', 'Off');
set(handles.pushbuttonLASSO, 'Enable', 'Off');

set(handles.pushbuttonSaveDecS, 'Enable', 'Off');
set(handles.pushbuttonSaveCalculations, 'Enable', 'Off');



function loadSignal(hObject, eventdata, handles)
%{
    Load data: signal, which path is placed in import.fpath.signal
%}

global import;
global yO;

y = load(import.fpath.signal);
yO = nrmlz01(y);

handles.current_data = yO;
plot(handles.current_data);
set(handles.textNAME, 'String', 'BOLD Output Signal');

set(handles.text1, 'String', import.file.signal);




function testSignalSpectrum(hObject, eventdata, handles)
%{
    Short test whether the signal has useful spectrum.
    The first parameter in a*HRf'+b should be positive!
%}

global yO;
global hrf;

spectr = abs(fft(yO)).^2;
[vB,spB] = fittingSpectrumPiHRf(spectr,hrf);

if vB(1)<=0 
    set(handles.textWarning,'String','Warning! Atypical signal spectra.');
end;



function loadingParameters(hObject, eventdata, handles)
%{
    Loading the parameters needed for calculations.
%}
global parameter;

parameter = usualParameters;


% --- Executes on button press in pushbuttonImpFrames.
function pushbuttonImpFrames_Callback(hObject, eventdata, handles)
% hObject    handle to pushbuttonImpFrames (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

%{
    Dialog for uploading frames from the movie.
%}

global import;

[filenameFr pathnameFr] = uigetfile({'*.mat'}, 'Select collection of frames');
import.fpath.frames = strcat(pathnameFr, filenameFr);
import.file.frames = filenameFr;

loadFrames(hObject, eventdata, handles);


function loadFrames(hObject, eventdata, handles)
%{
   Loading collection of frames.
%}

global import;
global frames;
global frTimes;

load(import.fpath.frames);
set(handles.textImpFrames, 'String', import.file.frames);

function loadMovie(hObject, eventdata, handles)
%{
    Dialog for uploading movie.
%}

global import;
global vi;

[filename pathname] = uigetfile({'*.mp4','*.avi'}, 'Select movie');
import.fpath.movie = strcat(pathname, filename);
import.file.movie = filename;

vi = VideoReader(import.fpath.movie);
set(handles.textImpMovie, 'String', import.file.movie);

% --- Executes on button press in pushbuttonImpMovie.
function pushbuttonImpMovie_Callback(hObject, eventdata, handles)
% hObject    handle to pushbuttonImpMovie (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

%{
    Uploading movie. Exacting frames.
%}

loadMovie(hObject, eventdata, handles);
exactFrames(hObject, eventdata, handles);



function loadKernel(hObject, eventdata, handles)
%{
    Dialog (or saved path) for uploading HRF.
%}

global import;
global parameter;
global hrf;

if get(handles.checkboxDefKernel,'Value') == get(handles.checkboxDefKernel,'Max')
    defaultKernel(hObject, eventdata, handles);
else
    [filename pathname] = uigetfile({'*.dat'}, 'Select file (HRF)');
    import.fpath.HRf = strcat(pathname, filename);
    import.file.HRf = filename;
end;

hrf = parameter.constForHRF*load(import.file.HRf);
%hrf = load(import.file.HRf);
set(handles.textHRf, 'String', import.file.HRf);

function defaultKernel(hObject, eventdata, handles)
%{
    Load default HRF.
%}

global import;

%import.fpath.HRf = 'Input/HRf/hrf.dat';
import.file.HRf = 'hrf.dat';
set(handles.textHRf, 'String', import.file.HRf);    


% --- Executes on button press in pushbuttonImpHRf.
function pushbuttonImpHRf_Callback(hObject, eventdata, handles)
% hObject    handle to pushbuttonImpHRf (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

%{
    Upload kernel (Haemodynamic Response Function).
%}

global import;

loadKernel(hObject, eventdata, handles);




% --- Executes on button press in radiobuttonLoadFrames.
function radiobuttonLoadFrames_Callback(hObject, eventdata, handles)
% hObject    handle to radiobuttonLoadFrames (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of radiobuttonLoadFrames
if get(handles.radiobuttonLoadFrames,'Value') == get(handles.radiobuttonLoadFrames,'Max')
    set(handles.pushbuttonImpFrames,'Enable','On');
    set(handles.pushbuttonImpMovie,'Enable','Off');
    set(handles.checkboxCalcFr,'Enable','Off');
end;



% --- Executes on button press in radiobuttonLoadMovie.
function radiobuttonLoadMovie_Callback(hObject, eventdata, handles)
% hObject    handle to radiobuttonLoadMovie (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of radiobuttonLoadMovie
if get(handles.radiobuttonLoadMovie,'Value') == get(handles.radiobuttonLoadMovie,'Max')
    set(handles.pushbuttonImpMovie,'Enable','On');
    set(handles.pushbuttonImpFrames,'Enable','Off');
    set(handles.checkboxCalcFr,'Enable','On');
end;




% --- Executes on button press in checkboxDefKernel.
function checkboxDefKernel_Callback(hObject, eventdata, handles)
% hObject    handle to checkboxDefKernel (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of checkboxDefKernel





% --- Executes on button press in pushbuttonImpSpectrum.
function pushbuttonImpSpectrum_Callback(hObject, eventdata, handles)
% hObject    handle to pushbuttonImpSpectrum (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

loadSpectr(hObject,eventdata,handles);



function loadSpectr(hObject,eventdata,handles)
%{
    Load spectrum.
%}

global import;
global spectr;
global yO;

checkSettings(hObject, eventdata, handles);

if get(handles.radiobuttonSpDef,'Value') == get(handles.radiobuttonSpDef,'Max')
    defaultSpectr(hObject,eventdata,handles);
end;

if get(handles.radiobuttonSpFit,'Value') == get(handles.radiobuttonSpFit,'Max')
    fitSpectr(hObject,eventdata,handles);
end;

if get(handles.radiobuttonSpLoad,'Value') == get(handles.radiobuttonSpLoad,'Max')
    [filename pathname] = uigetfile({'*.dat'}, 'Select spectrum');
    import.fpath.spectr = strcat(pathname, filename);
    import.file.spectr = filename;
    
    spectr = load(import.fpath.spectr);
    
    if length(spectr)~=length(yO)
        set(handles.textWarning,'String','Uncorrect size of the spectrum.');
    else 
        set(handles.textWarning,'String','');
    end;
end;

[d1,d2] = size(spectr);
if d1<d2
    spectr = spectr';
end;



function defaultSpectr(hObject, eventdata, handles)
%{
    Load default spectrum.
%}

global spectr;
global hrf;
global yO;

% Load "standard" parameters for scaling: a*HRF+b
% v = (v(1),v(2)) = (a,b).
load('defaultParameters.mat');

% Finding the spectra of HRf and scaling it
H = ToeplitzMatrix(hrf,length(yO));
yt = zeros(1,length(yO));
yt(1,1) = 1;
yC = H*yt';
power = abs(fft(yC)).^2;

spectr0 = v(1)*power(1:round(length(yO)/2)) + v(2);
spectr = [spectr0; spectr0(end:-1:1)];



function fitSpectr(hObject,eventdata,handles)
%{
    Estimate spectr from the signal
%}

global spectr;
global hrf;
global yO;
spectr0 = (abs(fft(yO))).^2;

% Finding the parameters of spectra fitting
spectr0c = spectr0;
[vB,spectr] = fittingSpectrumPiHRf(spectr0c,hrf);




% --- Executes on button press in checkboxDefSpectrum.
function checkboxDefSpectrum_Callback(hObject, eventdata, handles)
% hObject    handle to checkboxDefSpectrum (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of checkboxDefSpectrum



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% CALCULATIONS %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% --- Executes on button press in pushbuttonCalculations.
function pushbuttonCalculations_Callback(hObject, eventdata, handles)
% hObject    handle to pushbuttonCalculations (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

%{
    Make calculations: level 1.
%}

global settings;
makeCalculations_first(hObject, eventdata, handles);

deconvolutionButtonsAvailability(hObject, eventdata, handles);



function makeCalculations_first(hObject, eventdata, handles)
%{
    Make calculations: level 2.
    Creating 'estimate' - structure of estimates
    Creating 'collection' - structure of collections of estimates
%}

global estimate;
global collection;
global def;
global peaksAmount;

estimate = struct();
collection = struct();
def = struct();
peaksAmount = struct();


checkSettings(hObject, eventdata, handles);
makeCalculation(hObject, eventdata, handles);
updateSignalType(hObject, eventdata, handles);


function makeCalculation(hObject, eventdata, handles)
%{
    Make calculations: level 3.
%}

global yO;
global settings;
global yF;
global spectr;
global hrf;

checkSettings(hObject, eventdata, handles);

if settings.calculations.Filtering == 1
    loadSpectr(hObject,eventdata,handles);
    set(handles.radiobuttonFilSignal,'Enable','On')
    if settings.calculations.OriginalSignal == 0
        set(handles.radiobuttonFilSignal,'Value', 1);
    end;
else
    set(handles.radiobuttonFilSignal,'Enable','Off')
end;

if settings.calculations.OriginalSignal == 1
    set(handles.radiobuttonOrSignal,'Enable','On');
    if settings.calculations.Filtering == 0
        set(handles.radiobuttonOrSignal,'Value', 1);
    end;
else
    set(handles.radiobuttonOrSignal,'Enable','Off')
end;
checkSettings(hObject, eventdata, handles);

wT = 0;
dwT = 1/((settings.calculations.OriginalSignal+settings.calculations.Filtering)*(settings.calculations.DSC+settings.calculations.OLS+settings.calculations.LASSO));
h = waitbar(0,'Calculating of estimates. Please wait...');

if settings.calculations.OriginalSignal == 1
    if settings.calculations.DSC == 1
        wT = wT+dwT;
        h = waitbar(wT);
        calculateEstimate(yO,'original','DSC');
    end;

    if settings.calculations.OLS == 1
        wT = wT+dwT;
        h = waitbar(wT);
        
        calculateEstimate(yO,'original','OLS');
    end;

    if settings.calculations.LASSO == 1
        wT = wT+dwT;
        h = waitbar(wT);
        
        calculateEstimate(yO,'original','LASSO');
    end;
end;

if settings.calculations.Filtering == 1

    [v,spectrF] = fittingSpectrumPiHRf(spectr,hrf);
    yF = filteringSignalHRf(yO,spectrF,hrf);
    if settings.calculations.DSC == 1
        wT = wT+dwT;
        h = waitbar(wT);
            
        calculateEstimate(yF,'filtered','DSC');
    end;

    if settings.calculations.OLS == 1
        wT = wT+dwT;
        h = waitbar(wT);
            
        calculateEstimate(yF,'filtered','OLS');
    end;

    if settings.calculations.LASSO == 1
        wT = wT+dwT;
        h = waitbar(wT);
            
        calculateEstimate(yF,'filtered','LASSO');
     end;
end;

updateSignalType(hObject, eventdata, handles);
close(h);

if settings.calculations.Fr == 1
    exactFrames(hObject, eventdata, handles);
end;

set(handles.pushbuttonSaveDecS, 'Enable', 'On');
set(handles.pushbuttonSaveCalculations, 'Enable', 'On');




function exactFrames(hObject, eventdata, handles)
%{
    Exacting frames from the video.
%}

global vi;
global frames;
global settings;

sampleRate = settings.calculations.TR1;

frames = {};
maxT = round(vi.Duration/sampleRate);

if vi.Duration<maxT 
    maxT = maxT-1;
end;

h = waitbar(0,'Exacting frames from the movie. Please wait...');
for k = 1:maxT
    vi.CurrentTime = k*sampleRate;
    frames{k} = readFrame(vi);
    h = waitbar(k/maxT);
end
close(h);


function calculateEstimate(y,signalType,method)
%{
    Make calculations for signal y.
%}
global estimate;
global collection;
global def;
global peaksAmount;

global parameter;
global hrf;
global closestPoint;

parameterF = parameter;
parameterF.hrf = hrf;


switch method
case 'DSC'
    estimate.(signalType).(method) = deconvEstDSC(y, parameterF);
case 'OLS'
    estimate.(signalType).(method) = deconvEstOLS(y, parameterF);
case 'LASSO'
    estimate.(signalType).(method) = deconvEstLASSO(y, parameterF);
end;

% recommended number of peaks
if strcmp(method, 'OLS')
    def.(signalType).(method) = round(length(estimate.(signalType).OLS)*0.10);
else
    def.(signalType).(method) = length(find(estimate.(signalType).(method)));
end;

% possible estimates
switch method
case 'DSC'
    collection.(signalType).DSC = deconvEstDSCcollection(y, parameterF);
case 'OLS'
    collection.(signalType).OLS = deconvEstOLScollection(y, parameterF);
case 'LASSO'
    collection.(signalType).LASSO = deconvEstLASSOcollection(y, parameterF);
end;

% s - vector, r - value, which I'd like to find in s
closestPoint = @(s,r) find(abs(s-r) == min(abs(s-r)));

% number of peaks in each column in array h
peaks = @(h) arrayfun(@(k) length(find(h(:,k)~=0)),1:size(h,2));

peaksAmount.(signalType).(method) = peaks(collection.(signalType).(method));

function updateCurrentSignal(hObject, eventdata, handles)
%{
    Updating current signal: y = Original Signal or y = Filtered Signal.
%}
global settings;
global yO;
global yF;
global y;

if settings.originalSignal == 1 
    y = yO;
end;
if settings.filteredSignal == 1 
    y = yF;
end;




% --- Executes on button press in radiobuttonFS.
function radiobuttonFS_Callback(hObject, eventdata, handles)
% hObject    handle to radiobuttonFS (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of radiobuttonFS





% --- Executes on button press in checkboxCalcDSC.
function checkboxCalcDSC_Callback(hObject, eventdata, handles)
% hObject    handle to checkboxCalcDSC (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of checkboxCalcDSC

checkSettings(hObject, eventdata, handles);


% --- Executes on button press in checkboxCalcOLS.
function checkboxCalcOLS_Callback(hObject, eventdata, handles)
% hObject    handle to checkboxCalcOLS (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of checkboxCalcOLS

checkSettings(hObject, eventdata, handles);

% --- Executes on button press in checkboxCalcLASSO.
function checkboxCalcLASSO_Callback(hObject, eventdata, handles)
% hObject    handle to checkboxCalcLASSO (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of checkboxCalcLASSO

checkSettings(hObject, eventdata, handles);


% --- Executes on button press in checkboxCalcOrS.
function checkboxCalcOrS_Callback(hObject, eventdata, handles)
% hObject    handle to checkboxCalcOrS (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of checkboxCalcOrS

checkSettings(hObject, eventdata, handles);

% --- Executes on button press in checkboxCalcOrS.
function checkboxCalcFiltering_Callback(hObject, eventdata, handles)
% hObject    handle to checkboxCalcOrS (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of checkboxCalcOrS

checkSettings(hObject, eventdata, handles);

% --- Executes on button press in checkboxCalcFr.
function checkboxCalcFr_Callback(hObject, eventdata, handles)
% hObject    handle to checkboxCalcFr (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of checkboxCalcFr

checkSettings(hObject, eventdata, handles);



function checkSettings(hObject, eventdata, handles)
%{
    Check settings.
%}
global settings;

settings.calculations.DSC = get(handles.checkboxCalcDSC,'Value');
settings.calculations.OLS = get(handles.checkboxCalcOLS,'Value');
settings.calculations.LASSO = get(handles.checkboxCalcLASSO,'Value');
settings.calculations.OriginalSignal = get(handles.checkboxCalcOrS,'Value');
settings.calculations.Filtering = get(handles.checkboxCalcFiltering,'Value');
settings.calculations.Fr = get(handles.checkboxCalcFr,'Value');

settings.originalSignal = get(handles.radiobuttonOrSignal,'Value');
settings.filteredSignal = get(handles.radiobuttonFilSignal,'Value');

settings.spectrumDef = get(handles.radiobuttonSpDef,'Value');
settings.spectrumFit = get(handles.radiobuttonSpFit,'Value');
settings.spectrumLoad = get(handles.radiobuttonSpLoad,'Value');

settings.plotStyle.sparse = 1;
settings.plotStyle.cont = 0;
    
settings.calculations.TR1 = str2num(get(handles.editSpeed1,'String'));
settings.calculations.TR2 = str2num(get(handles.editSpeed2,'String'));

%settings.movieuse = get(handles.checkboxMovieBlock,'Value');

function updateSignalType(hObject, eventdata, handles)
%{
    Update signal type, then update the current signal.
%}

global signalType;
global settings;

checkSettings(hObject, eventdata, handles);

if settings.originalSignal == 1 
    signalType = 'original';
end;
if settings.filteredSignal == 1
   signalType = 'filtered';
end;
updateCurrentSignal(hObject, eventdata, handles);


% --- Executes on button press in radiobuttonOrSignal.
function radiobuttonOrSignal_Callback(hObject, eventdata, handles)
% hObject    handle to radiobuttonOrSignal (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of radiobuttonOrSignal

%{
    Update settings (signal type) according to the radiobutton = original signal.
%}
global signalType;

checkSettings(hObject, eventdata, handles);

if get(handles.radiobuttonOrSignal,'Value') == get(handles.radiobuttonOrSignal,'Max')
    signalType = 'original';
end;

if get(handles.radiobuttonOrSignal,'Value') == get(handles.radiobuttonOrSignal,'Min')
       signalType = 'filtered';
end;
updateSignalType(hObject, eventdata, handles);


% --- Executes on button press in radiobuttonFilSignal.
function radiobuttonFilSignal_Callback(hObject, eventdata, handles)
% hObject    handle to radiobuttonFilSignal (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of radiobuttonFilSignal

%{
    Update settings (signal type) according to the radiobutton = filtered signal.
%}
global signalType;

checkSettings(hObject, eventdata, handles);

if get(handles.radiobuttonFilSignal,'Value') == get(handles.radiobuttonFilSignal,'Max')
    signalType = 'filtered';
end;

if get(handles.radiobuttonFilSignal,'Value') == get(handles.radiobuttonFilSignal,'Min')
       signalType = 'original';
end;

updateSignalType(hObject, eventdata, handles);



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%% DISPLAY RESULTS %%%%%%%%%%%%%%%%%%%%%%%%%%%%%


% --- Executes on button press in pushbuttonDSC.
function pushbuttonDSC_Callback(hObject, eventdata, handles)
% hObject    handle to pushbuttonDSC (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

%{
    Show the Danzig Selector estimate.
%}

global currentEstimate;
global estimate;
global collection;
global closestPoint;
global peaksAmount;
global signalType;

currentEstimate = estimate.(signalType).DSC;

if get(handles.checkboxKnownNumberOfPeaks,'Value') == get(handles.checkboxKnownNumberOfPeaks,'Max')
    num = str2num(handles.editDSC.String);
    closeNum = min(closestPoint(peaksAmount.(signalType).DSC,num));
    currentEstimate = collection.(signalType).DSC(:,closeNum);
end;

plotSignals(hObject, eventdata, handles);
set(handles.textNAME, 'String', ['DSC Estimate, ' signalType ': ' mat2str(length(find(currentEstimate))) ' peaks' ]);


% --- Executes on button press in pushbuttonOLS.
function pushbuttonOLS_Callback(hObject, eventdata, handles)
% hObject    handle to pushbuttonOLS (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

%{
    Show the Ordinary Least Squares estimate.
%}

global estimate;
global collection;
global closestPoint;
global peaksAmount;
global signalType;
global currentEstimate;

currentEstimate = estimate.(signalType).OLS;

if get(handles.checkboxKnownNumberOfPeaks,'Value') == get(handles.checkboxKnownNumberOfPeaks,'Max')
    num = str2num(handles.editOLS.String);
    closeNum = min(closestPoint(peaksAmount.(signalType).OLS,num));
    currentEstimate = collection.(signalType).OLS(:,closeNum);
end;

plotSignals(hObject, eventdata, handles);
set(handles.textNAME, 'String', ['OLS Estimate, ' signalType ': ' mat2str(length(find(currentEstimate))) ' peaks' ]);


% --- Executes on button press in pushbuttonLASSO.
function pushbuttonLASSO_Callback(hObject, eventdata, handles)
% hObject    handle to pushbuttonLASSO (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

%{
    Show the LASSO estimate.
%}

global currentEstimate;
global estimate;
global collection;
global closestPoint;
global peaksAmount;
global signalType;

currentEstimate = estimate.(signalType).LASSO;

if get(handles.checkboxKnownNumberOfPeaks,'Value') == get(handles.checkboxKnownNumberOfPeaks,'Max')
    num = str2num(handles.editLASSO.String);
    closeNum = min(closestPoint(peaksAmount.(signalType).LASSO,num));
    currentEstimate = collection.(signalType).LASSO(:,closeNum);
end;

plotSignals(hObject, eventdata, handles);
set(handles.textNAME, 'String', ['LASSO Estimate, ' signalType ': ' mat2str(length(find(currentEstimate))) ' peaks' ]);



% --- Executes on button press in checkboxKnownNumberOfPeaks.
function checkboxKnownNumberOfPeaks_Callback(hObject, eventdata, handles)
% hObject    handle to checkboxKnownNumberOfPeaks (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of checkboxKnownNumberOfPeaks

%{
    Fill the field with the number of non-zero peaks in the estimate.
%}

global def;
global signalType;
global settings;

if settings.calculations.DSC==1
    if isempty(handles.editDSC.String)==1
        set(handles.editDSC, 'String', mat2str(def.(signalType).DSC));
    end;
end;
if settings.calculations.OLS==1
    if isempty(handles.editOLS.String)==1
        set(handles.editOLS, 'String', mat2str(def.(signalType).OLS));
    end;
end;
if settings.calculations.LASSO==1
    if isempty(handles.editLASSO.String)==1
        set(handles.editLASSO, 'String', mat2str(def.(signalType).LASSO));
    end;
end;




function editDSC_Callback(hObject, eventdata, handles)
% hObject    handle to editDSC (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of editDSC as text
%        str2double(get(hObject,'String')) returns contents of editDSC as a double


% --- Executes during object creation, after setting all properties.
function editDSC_CreateFcn(hObject, eventdata, handles)
% hObject    handle to editDSC (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function editOLS_Callback(hObject, eventdata, handles)
% hObject    handle to editOLS (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of editOLS as text
%        str2double(get(hObject,'String')) returns contents of editOLS as a double


% --- Executes during object creation, after setting all properties.
function editOLS_CreateFcn(hObject, eventdata, handles)
% hObject    handle to editOLS (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function editLASSO_Callback(hObject, eventdata, handles)
% hObject    handle to editLASSO (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of editLASSO as text
%        str2double(get(hObject,'String')) returns contents of editLASSO as a double



% --- Executes during object creation, after setting all properties.
function editLASSO_CreateFcn(hObject, eventdata, handles)
% hObject    handle to editLASSO (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in pushbuttonShowFrame.
function pushbuttonShowFrame_Callback(hObject, eventdata, handles)
% hObject    handle to pushbuttonShowFrame (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

%{
    Show the current frame.
%}

global settings;
global frames;

dcm_obj = datacursormode();
set(dcm_obj,'DisplayStyle','datatip',...
    'SnapToDataVertex','off','Enable','on')

c_info = getCursorInfo(dcm_obj);

FR = settings.calculations.TR1;
SR = settings.calculations.TR2;

curPoint = round(c_info.Position(1));
curTime = round(curPoint*SR/FR);

figure;
imshow(frames{curTime});
title(['Point ' mat2str(curPoint) ', second ' mat2str(curTime*FR)]);


% --- Executes on button press in pushbuttonShFr2.
function pushbuttonShFr2_Callback(hObject, eventdata, handles)
% hObject    handle to pushbuttonShFr2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

%{
    Show the current and the previous frames.
%}


global frames;
global settings;

dcm_obj = datacursormode();
set(dcm_obj,'DisplayStyle','datatip',...
    'SnapToDataVertex','off','Enable','on')

FR = settings.calculations.TR1;
SR = settings.calculations.TR2;

c_info = getCursorInfo(dcm_obj);

curPoint = round(c_info.Position(1));
curTime = round(curPoint*SR/FR);


figure;
if curTime>1
   subplot(1,2,1); imshow(frames{curTime-1});
end;
subplot(1,2,2); imshow(frames{curTime});




% --- Executes on button press in pushbuttonShPosFr.
function pushbuttonShPosFr_Callback(hObject, eventdata, handles)
% hObject    handle to pushbuttonShPosFr (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

%{
    Show frames for positive peaks.
%}


global currentEstimate;
global frames;
global settings;

FR = settings.calculations.TR1;
SR = settings.calculations.TR2;

figure;
peaks = find(currentEstimate>0);
l = length(peaks);
nSbpl = round(sqrt(l));
if nSbpl^2 < l 
    nSbpl = nSbpl+1;
end;
for k = 1:l
    subplot(nSbpl,nSbpl,k);
    curTime = round(peaks(k)*SR/FR);
    imshow(frames{curTime});
    title(['Point ' mat2str(curTime)]);
end



function plotSignals(hObject, eventdata, handles)
%{
    Show the result on the chart.
%}
global currentEstimate;
global y;
global settings;

checkSettings(hObject, eventdata, handles);
if settings.plotStyle.sparse==1
    
    positions = find(currentEstimate);
    yCoord = [positions'; positions'];
    xCoord = [zeros(1,length(positions));(currentEstimate(positions))'];

    plot(1:length(y),(y),1:length(y),zeros(1,length(y)),'--');
    line(yCoord,xCoord,'Color','r');
else
    plot(1:length(y),(y),1:length(y),(currentEstimate));
end;



% --- Executes on button press in pushbuttonShowP.
function pushbuttonShowP_Callback(hObject, eventdata, handles)
% hObject    handle to pushbuttonShowP (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

%{
    Show frames from the time period.
%}


global frames;
global settings;

FR = settings.calculations.TR1;
SR = settings.calculations.TR2;

timePoint1 = str2num(handles.editShPfrom.String);
timePoint2 = str2num(handles.editShPto.String);

figure;

if timePoint1<timePoint2
    peaks = timePoint1:timePoint2;
    l = length(peaks);
    nSbpl = round(sqrt(l));
    if nSbpl^2 < l 
        nSbpl = nSbpl+1;
    end;
    for k = 1:l
        subplot(nSbpl,nSbpl,k);
        curTime = round(peaks(k)*SR/FR);
        imshow(frames{curTime});
        title(['Point ' mat2str(curTime)]);
    end;
end;


function editShPfrom_Callback(hObject, eventdata, handles)
% hObject    handle to editShPfrom (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of editShPfrom as text
%        str2double(get(hObject,'String')) returns contents of editShPfrom as a double


% --- Executes during object creation, after setting all properties.
function editShPfrom_CreateFcn(hObject, eventdata, handles)
% hObject    handle to editShPfrom (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function editShPto_Callback(hObject, eventdata, handles)
% hObject    handle to editShPto (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of editShPto as text
%        str2double(get(hObject,'String')) returns contents of editShPto as a double


% --- Executes during object creation, after setting all properties.
function editShPto_CreateFcn(hObject, eventdata, handles)
% hObject    handle to editShPto (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in pushbuttonShowF.
function pushbuttonShowF_Callback(hObject, eventdata, handles)
% hObject    handle to pushbuttonShowF (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

%{
    Show the particular frame.
%}
global frames;
global settings;

FR = settings.calculations.TR1;
SR = settings.calculations.TR2;

timeSec = str2num(handles.editShFsecond.String);

figure;
curTime = round(timeSec/FR);
imshow(frames{curTime});
title(['Point ' mat2str(round(timeSec/SR)) ', second ' mat2str(timeSec)]);


function editShFpoint_Callback(hObject, eventdata, handles)
% hObject    handle to editShFpoint (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of editShFpoint as text
%        str2double(get(hObject,'String')) returns contents of editShFpoint as a double

%{
	Editing the sampling rate.
%}

global settings;

SR = settings.calculations.TR2;

set(handles.editShFsecond,'String',mat2str(str2num(handles.editShFpoint.String)*SR));

% --- Executes during object creation, after setting all properties.
function editShFpoint_CreateFcn(hObject, eventdata, handles)
% hObject    handle to editShFpoint (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function editShFframe_Callback(hObject, eventdata, handles)
% hObject    handle to editShFframe (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of editShFframe as text
%        str2double(get(hObject,'String')) returns contents of editShFframe as a double

% --- Executes during object creation, after setting all properties.
function editShFframe_CreateFcn(hObject, eventdata, handles)
% hObject    handle to editShFframe (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in radiobuttonSpSignal.
function radiobuttonSpSignal_Callback(hObject, eventdata, handles)
% hObject    handle to radiobuttonSpSignal (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of radiobuttonSpSignal


% --- Executes on button press in radiobuttonConSignal.
function radiobuttonConSignal_Callback(hObject, eventdata, handles)
% hObject    handle to radiobuttonConSignal (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of radiobuttonConSignal



function editShFsecond_Callback(hObject, eventdata, handles)
% hObject    handle to editShFsecond (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of editShFsecond as text
%        str2double(get(hObject,'String')) returns contents of editShFsecond as a double
global settings;

SR = settings.calculations.TR2;

set(handles.editShFpoint,'String', mat2str(round(str2num(handles.editShFsecond.String)/SR)));



% --- Executes during object creation, after setting all properties.
function editShFsecond_CreateFcn(hObject, eventdata, handles)
% hObject    handle to editShFsecond (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% OTHER %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



% --- Executes during object creation, after setting all properties.
function uibuttongroup7_CreateFcn(hObject, eventdata, handles)
% hObject    handle to uibuttongroup7 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called


% --- Executes during object creation, after setting all properties.
function uibuttongroup5_CreateFcn(hObject, eventdata, handles)
% hObject    handle to uibuttongroup7 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called


% --- Executes when figure1 is resized.
function figure1_SizeChangedFcn(hObject, eventdata, handles)
% hObject    handle to figure1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% THE END :) %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



function editSpeed1_Callback(hObject, eventdata, handles)
% hObject    handle to editSpeed1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of editSpeed1 as text
%        str2double(get(hObject,'String')) returns contents of editSpeed1 as a double


% --- Executes during object creation, after setting all properties.
function editSpeed1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to editSpeed1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function editSpeed2_Callback(hObject, eventdata, handles)
% hObject    handle to editSpeed2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of editSpeed2 as text
%        str2double(get(hObject,'String')) returns contents of editSpeed2 as a double


% --- Executes during object creation, after setting all properties.
function editSpeed2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to editSpeed2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

%{
% --- Executes on button press in checkboxMovieBlock.
function checkboxMovieBlock_Callback(hObject, eventdata, handles)
% hObject    handle to checkboxMovieBlock (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of checkboxMovieBlock

if get(handles.checkboxMovieBlock,'Value') == 1
    set(handles.uibuttongroup4,'Visible','On');
    set(handles.uipanel4,'Visible','On');
else
    set(handles.uibuttongroup4,'Visible','Off');
    set(handles.uipanel4,'Visible','Off');    
end;
%}

% --- Executes during object creation, after setting all properties.
function checkboxMovieBlock_CreateFcn(hObject, eventdata, handles)
% hObject    handle to checkboxMovieBlock (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called


% --- Executes during object creation, after setting all properties.
function checkboxCalcOrS_CreateFcn(hObject, eventdata, handles)
% hObject    handle to checkboxMovieBlock (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called


% --- Executes on button press in radiobuttonSpDef.
function radiobuttonSpDef_Callback(hObject, eventdata, handles)
% hObject    handle to radiobuttonSpDef (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of radiobuttonSpDef
checkSettings(hObject, eventdata, handles);


% --- Executes on button press in radiobuttonSpFit.
function radiobuttonSpFit_Callback(hObject, eventdata, handles)
% hObject    handle to radiobuttonSpFit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of radiobuttonSpFit
checkSettings(hObject, eventdata, handles);


% --- Executes on button press in radiobuttonSpLoad.


function radiobuttonSpLoad_Callback(hObject, eventdata, handles)
% hObject    handle to radiobuttonSpLoad (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of radiobuttonSpLoad
checkSettings(hObject, eventdata, handles);
